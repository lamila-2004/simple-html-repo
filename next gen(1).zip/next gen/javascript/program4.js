
let n=Number(prompt("enter the  number"))
let i=1
while(i<=10)
{
    document.write("${i}", "*" ,"${n}"=i*n)
    i++
}




