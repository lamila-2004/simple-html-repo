//var,let-normal variables,we can reassign values
//const-constant variabless
var a=10 
var b=20
const c=10
let d=30
e=98//initilization
console.log("a",a)
console.log("b",b)
console.log("c",c)
console.log("d",d)
console.log("e",e)
var b=76 ///var allows redeclaration and assignment
///let d=36 let do not allow redeclaration and assignment,bloack scope do not redeclare
if(true)
{
    let n1=30
    var n2=20
    const n3=50
   console.log("n1",n1)//not accesible outside the block because it was a let 

   
}
console.log("outside the block")
    

console.log("n2",n2)// accesible outside the block because it was a var
console.log("n3",n3)//not accesible outside the block because it was a const
