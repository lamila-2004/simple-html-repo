let student={'name':'hanna','marks':67,'sub':'ai'}
console.log(student)
console.log(typeof(name))
student.name="manu v"
console.log("student object",student)
student.grade='a+'
console.log("student object after adding grade",student)
student.place="thozhiyoor"
console.log("student object after adding place",student)
delete student.place
console.log("student object after deleteing place",student)
for(let key in student)
{
    console.log("key",key)
    console.log("value",student[key])
}