alert("working")
var n1=Number(prompt("enter the number"))
     if (n1%2==0){
        document.write("number is even")
    }
    else{
        document.write("number is odd")
    }
