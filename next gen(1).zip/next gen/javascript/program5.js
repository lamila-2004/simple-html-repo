//read a array from user and create 2 new arrays one with even numbers and one with odd numbers
//input-[4,10,8,2]