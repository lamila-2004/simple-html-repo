let i=1
while(i<10){
console.log(i)
i++
}
let num=2
let sum=0
while(num<1000)
{
    if(num%5!=0){
        sum=sum+num
    num=num+2
    }
}
console.log("sum is",sum)