//function definition 
//function fnmame(parmeter)
//{
// function body
//}
function greet(name)
{
    console.log("good morning  "+name)
    return "success"
}
//function call
greet("hanna")
greet("janu")
function add(num1,num2)
{
    return num1+num2
}
let res=add(5,6)
console.log("sum is",res)
//create a functionthat accepet 3 numbers and return largest number
function  largest(num1,num2,num3){
   return num1,num2,num3
} 
if(num1>num2){
    console.log("${num1} was larger")
}
else if(num2>num3){
    console.log("${num2}was larger")

}
else{
    console.log("${num3} was larger")
}