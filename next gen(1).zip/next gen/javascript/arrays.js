let marks=[10,20,30,40]
console.log(marks)
console.log(typeof(marks))
console.log(marks[2])
console.log(marks[3])
//for updation 
marks[0]=11
marks[3]=100
console.log("updated marks",marks)
//adding elements
marks.push(77)//it was addedd as last element
console.log("array after adding one element ",marks)
//last element wiil be removed from array
marks.pop()
console.log("array after deleting one element ",marks)
//iterating array
for(let i=0;i<marks.length;i++)
{
    console.log(marks[i])
}
 //for of loop onlyy used in array
for(element in marks)
{

    console.log(marks[element])
}
