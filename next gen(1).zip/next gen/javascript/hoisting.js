let a=10
console.log(a);
console.log(c)
var c=50 // it only put like undefined not give a error