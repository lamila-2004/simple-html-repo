let test=()=>{
    console.log("test is working")
}
let add=(num1,num2)=>{
    console.log("sum is",num1+num2)
}
let prod=(n1,n2)=>{
    console.log("product is",n1*n2)
}
test()
add(6,7)
prod(9,4)