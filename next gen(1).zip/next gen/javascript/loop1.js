// //for(init,condition,updation)
// {
//     body of loop

// }
// let sum=0
// for (let i=2;i<=1000;i=i+2)//counting loop
//  {
//   if(i%5==0) 
//         continue //skipping iterations
//     sum=sum+i;  
//  }
//  document.write("sum is",sum)
//display the sum of even numbers upto 1000 expect mutiples of 5
//let sum=0
// for (let i=2;i<=1000;i=i+2)//counting loop
//  {
//   if(i%5!==0) 
//         continue //skipping iterations
//     sum=sum+i;  
//  }
//  document.write("sum is",sum)