//find largest element in array
let marks=[10,20,30,40,50]
let large=marks[0]
for(let element of marks)
{
    if(element>large){
        large=element
    }
}
console.log("largest marks in the array",large)